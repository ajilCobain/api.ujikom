const authController = require('./authController');
const userController = require('./userController');

module.exports = {
    auth: authController,
    user: userController,
};